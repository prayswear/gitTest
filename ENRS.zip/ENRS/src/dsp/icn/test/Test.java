package dsp.icn.test;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.core.config.status.StatusConfiguration;

import dsp.icn.config.Config;
import dsp.icn.protocol.ICN_head;
import dsp.icn.util.BloomFilter;
import dsp.icn.util.SocketUtil;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class Test {

	public static void main(String[] args) {
		Test2();
	}

	public static void Test2() {
		Map<String, String> aMap = new HashMap<String, String>();
		log.info(aMap.get("1"));

	}

	public static void Test1() {
		byte[] recvMsg = new byte[Config.UDP_PACKET_LENGTH];
		try {
			DatagramSocket datagramSocket = new DatagramSocket(0);
			datagramSocket.setSoTimeout(1000);
			byte[] data = "hello".getBytes("utf-8");
			DatagramPacket packet = new DatagramPacket(data, data.length, InetAddress.getByName("127.0.0.1"), 9000);
			datagramSocket.send(packet);
			DatagramPacket recvPacket = new DatagramPacket(recvMsg, recvMsg.length);
			datagramSocket.receive(recvPacket);

		} catch (Exception e) {
			log.error(e.toString());

		}
	}

}
