package dsp.icn.model;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import dsp.icn.config.Config;
import dsp.icn.protocol.ControlMsg;
import dsp.icn.protocol.Register;
import dsp.icn.util.BloomFilter;

public class ContainerNode extends Thread {
	private static Logger logger = LogManager.getLogger(ContainerNode.class.getName());

	// 节点地址
	public String nodeAddress;
	// 节点端口
	public int nodePort;
	// 节点名字
	public String nodeName;
	// 节点编号
	public int nodeID;
	// 父节点
	public ContainerNode parentNode;
	// 节点层级类型
	public int nodeCategory;
	// 孩子集合
	public ArrayList<ContainerNode> childNodes = new ArrayList<ContainerNode>();
	// 邻居集合
	public ArrayList<ContainerNode> neighborNodes = new ArrayList<ContainerNode>();
	// 布隆过滤器，用于快速判断映射是否在本节点存储的布隆过滤器，错误概率1e-5，预期元素100000个
	public BloomFilter<String> bfFilter = new BloomFilter<String>(1.E-005D, 100000);
	// 映射哈希表
	public Map<String, String> dht = new HashMap<String, String>();
	// 映射序列号
	public Map<String, String> serialNum = new HashMap<String, String>();
	// 节点间时延信息
	public Map<Integer, String> distance = new HashMap<Integer, String>();
	// UDP套接字
	public DatagramSocket udpSocket;
	// 在本节点允许的查询时延上限
	public long ts = 1000;

	public ContainerNode() {

	}

	public ContainerNode(String address, int port, String name) {
		this.nodeAddress = address;
		this.nodePort = port;
		this.nodeName = name;
	}

	public void run() {
		super.run();
		showNodeInfo();
		try {
			this.udpSocket = new DatagramSocket(this.nodePort);
			logger.info("服务端启动...");
			for (;;) {
				byte[] udpData = new byte[Config.UDP_PACKET_LENGTH];
				DatagramPacket packet = new DatagramPacket(udpData, Config.UDP_PACKET_LENGTH);
				udpSocket.receive(packet);
				logger.info("udp packet received on " + this.nodeName);
				// SocketUtil.printHexString("###", infoBytes);
				// SocketHandler thread = new SocketHandler(packet, this);
				// thread.start();
			}
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e.toString());
		}

	}

	public boolean register(Register register) {
		Map<String, String> queryResult = new HashMap<String, String>();
		String EID = register.getEID();
		queryResult = parseNALocally(EID);
		if (Integer.parseInt(register.getSerial()) <= Integer.parseInt(queryResult.get("SERIAL"))) {
			return false;
		}
		dht.put(EID, register.getNA());
		serialNum.put(EID, register.getSerial());
		bfFilter.add(EID);
		// update father and children
		sendUdpPacket(parentNode, register);
		return true;

	}

	public Map<String, String> parseNA(String EID, long timestamp, long timeOut) {
		// TODO
		return null;
	}

	public Map<String, String> parseNALocally(String EID) {
		Map<String, String> result = new HashMap<String, String>();
		String na = dht.get(EID);
		if (na == null) {
			result.put("NA", "000000");
			result.put("SERIAL", "000000");
		} else {
			result.put("NA", na);
			result.put("SERIAL", serialNum.get(EID));
		}
		return result;
	}

	public Map<String, String> parseNAByNeighbor() {
		return null;
	}

	public Map<String, String> parseNAByChildren() {
		return null;

	}

	public String sendUdpPacket(ContainerNode node, ControlMsg msg) {

		return null;
	}

	public int getCategory() {
		return this.nodeCategory;
	}

	public void setCategory(int category) {
		this.nodeCategory = category;
	}

	public void setParent(ContainerNode node) {
		this.parentNode = node;
	}

	public void addChild(ContainerNode node) {
		this.childNodes.add(node);
	}

	public void addNeighbor(ContainerNode node) {
		this.neighborNodes.add(node);
	}

	public DatagramSocket getUdpSocket() {
		return udpSocket;
	}

	public void setUdpSocket(DatagramSocket udpSocket) {
		this.udpSocket = udpSocket;
	}

	public long getTs() {
		return ts;
	}

	public void setTs(long ts) {
		this.ts = ts;
	}

	/**
	 * 打印该节点信息
	 * 
	 */
	public void showNodeInfo() {
		String parentName = "";
		if (this.parentNode != null) {
			parentName = this.parentNode.nodeName;
		}
		ArrayList<String> childNodesName = new ArrayList<String>();
		for (ContainerNode temp : this.childNodes) {
			childNodesName.add(temp.nodeName);
		}
		ArrayList<String> neightborNodesName = new ArrayList<String>();
		for (ContainerNode temp : this.neighborNodes) {
			neightborNodesName.add(temp.nodeName);
		}
		String info = "\n###Node Info### " + "\n# Node ID:" + this.nodeID + "\n# Node Name:" + this.nodeName
				+ "\n# Node Category:" + this.nodeCategory + "\n# Node Address:" + this.nodeAddress + "\n# Node Port:"
				+ this.nodePort + "\n# Parent Name:" + parentName + "\n# Neightbor Nodes:" + neightborNodesName
				+ "\n# Child Nodes:" + childNodesName + "\n# TS:" + ts + "\n######";
		logger.info(info);
	}

}
