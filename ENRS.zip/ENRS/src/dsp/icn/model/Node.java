package dsp.icn.model;

import dsp.icn.config.Config;
import dsp.icn.util.BloomFilter;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Node {
	// 节点编号
	private int num;
	// 节点名字（16字节）
	private String EID;
	// 节点类型
	private int category;
	// 节点地址
	private String address;
	// 节点端口
	private int port;
	// 节点布隆过滤器，用于快速判断映射是否在本节点存储的布隆过滤器
	private BloomFilter<String> bfFilter = new BloomFilter<String>(Config.BF_FALSE_PROPORTION, Config.BF_EXPECTED_NUM);

	public Node(String address, int port) {
		this.address = address;
		this.port = port;
	}
}
