package dsp.icn.model;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import dsp.icn.config.Config;
import dsp.icn.protocol.ControlMsg;
import dsp.icn.protocol.ICN_head;
import dsp.icn.util.SocketUtil;
import lombok.extern.log4j.Log4j2;

@Log4j2

public class MsgSender extends Thread {
	private ICN_head icn_head;
	private ControlMsg msg;
	private Node dstNode;

	public MsgSender(Node srcNode, Node dstNode, ControlMsg msg) {
		icn_head = new ICN_head();
		icn_head.setSRC_EID(srcNode.getEID());
		icn_head.setDST_EID(dstNode.getEID());
		log.info(icn_head.toString());
		this.dstNode = dstNode;
		this.msg = msg;
	}

	public void sendUDPMsg() {
		byte[] headBytes = icn_head.ICN2bytes();
		byte[] msgBytes = msg.genContentData();
		try {
			DatagramSocket datagramSocket = new DatagramSocket(0);
			datagramSocket.setSoTimeout(1000);
			byte[] data = SocketUtil.addBytes(headBytes, msgBytes);
			log.info(SocketUtil.bytesToHexString(data));
			DatagramPacket sendPacket = new DatagramPacket(data, data.length,
					InetAddress.getByName(dstNode.getAddress()), dstNode.getPort());
			datagramSocket.send(sendPacket);
			datagramSocket.close();
		} catch (Exception e) {
			log.error(e.toString());

		}
	}
	

	@Override
	public void run() {
		byte[] headBytes = icn_head.ICN2bytes();
		byte[] msgBytes = msg.genContentData();
		byte[] recvMsg = new byte[Config.UDP_PACKET_LENGTH];
		try {
			DatagramSocket datagramSocket = new DatagramSocket(0);
			datagramSocket.setSoTimeout(1000);
			byte[] data = SocketUtil.addBytes(headBytes, msgBytes);
			log.info(SocketUtil.bytesToHexString(data));
			DatagramPacket sendPacket = new DatagramPacket(data, data.length,
					InetAddress.getByName(dstNode.getAddress()), dstNode.getPort());
			datagramSocket.send(sendPacket);
			DatagramPacket recvPacket = new DatagramPacket(recvMsg, recvMsg.length);
			datagramSocket.receive(recvPacket);
			datagramSocket.close();
		} catch (Exception e) {
			log.error(e.toString());

		}
		super.run();
	}

}
