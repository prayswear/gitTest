package dsp.icn.model;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import dsp.icn.protocol.ICN_head;
import dsp.icn.protocol.Register;
import dsp.icn.protocol.Register_Ack;
import dsp.icn.protocol.Search;
import dsp.icn.protocol.Search_Ack;
import dsp.icn.util.SocketUtil;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class SocketHandler extends Thread {
	public CNode node;
	public DatagramPacket packet;
	public DatagramSocket udpSocket;
	public byte[] packetData;
	public ICN_head icnHead;
	public byte[] payload;
	public DatagramSocket sendSocket;

	public SocketHandler(DatagramPacket packet, CNode node) {
		this.node = node;
		this.packet = packet;
		udpSocket = node.getUdpSocket();
		packetData = packet.getData();
		int icn_len = packetData[33];
		icnHead = new ICN_head(SocketUtil.subBytes(packetData, 0, icn_len));
		payload = SocketUtil.subBytes(packetData, icn_len, packetData.length - icn_len);
	}

	public byte[] registerHandler() {
		Register register = new Register();
		register.parseContentData(payload);
		Register_Ack register_ack = new Register_Ack();
		register_ack.setGroup(SocketUtil.BitToByte("00000010"));
		register_ack.setEID(register.getEID());
		if (node.register(icnHead.getSRC_EID(), register)) {
			register_ack.setAck(SocketUtil.BitToByte("00000001"));
		} else {
			register_ack.setAck(SocketUtil.BitToByte("00000010"));
		}
		return register_ack.genContentData();
	}

	public byte[] searchHandler() {
		Search search = new Search();
		search.parseContentData(payload);
		Mapping searchResult = node.parseNA(search);
		Search_Ack search_ack = new Search_Ack();
		search_ack.setEID(search.getEID());
		search_ack.setGroup(SocketUtil.BitToByte("00000100"));
		search_ack.setNA(searchResult.getNA());
		search_ack.setSerial(searchResult.getSerial());
		return search_ack.genContentData();
	}

	public void doResponse(byte[] payload) {
		String SRC_EID = icnHead.getSRC_EID();
		String DST_EID = icnHead.getDST_EID();
		icnHead.setDST_EID(SRC_EID);
		icnHead.setSRC_EID(DST_EID);
		byte[] infoBytes = icnHead.ICN2bytes();
		log.info(SocketUtil.bytesToHexString(infoBytes));
		infoBytes = SocketUtil.addBytes(infoBytes, payload);
		String responseHex = SocketUtil.bytesToHexString(infoBytes);
		log.info(responseHex);
		try {
			infoBytes = responseHex.getBytes("utf-8");
			packet = new DatagramPacket(infoBytes, infoBytes.length, packet.getAddress(), packet.getPort());
			udpSocket.send(packet);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void run() {
		super.run();
		log.info(icnHead.toString());
		int reqType = payload[0];
		byte[] response = new byte[0];
		if (reqType == 1) {
			response = registerHandler();
		} else if (reqType == 3) {
			response = searchHandler();
		}
		doResponse(response);
	}

}
