package dsp.icn.model;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import dsp.icn.config.Config;
import dsp.icn.protocol.ICN_head;
import dsp.icn.protocol.Register;
import dsp.icn.protocol.Search;
import dsp.icn.protocol.Search_Ack;
import dsp.icn.util.BloomFilter;
import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.extern.log4j.Log4j2;

@Data
@Log4j2
public class CNode extends Node {
	// 父亲节点
	private Node parentNode;
	// 邻居节点集合
	private ArrayList<Node> neighborNodes = new ArrayList<Node>();
	// 孩子节点集合
	private ArrayList<Node> childNodes = new ArrayList<Node>();
	// 本地映射哈希表
	private Map<String, Mapping> dht = new HashMap<String, Mapping>();
	// 节点间时延信息表
	private Map<Integer, String> distance = new HashMap<Integer, String>();
	// 节点时延上限
	private int ts;
	// 服务端 UDP socket
	private DatagramSocket udpSocket;

	public CNode(String address, int port) {
		super(address, port);
	}

	public void startService() {
		try {
			udpSocket = new DatagramSocket(getPort());
			log.info("服务端(" + getAddress() + ":" + getPort() + ")启动...");
			while (true) {
				byte[] udpData = new byte[Config.UDP_PACKET_LENGTH];
				DatagramPacket packet = new DatagramPacket(udpData, Config.UDP_PACKET_LENGTH);
				udpSocket.receive(packet);
				log.info("An UDP packet received on " + getEID());
				log.info(SocketUtil.bytesToHexString(packet.getData()));
				SocketHandler thread = new SocketHandler(packet, this);
				thread.start();
			}
		} catch (Exception e) {
			log.error(e.toString());
		}
	}

	public boolean register(String src_eid, Register register) {
		String content_EID = register.getEID();
		BloomFilter<String> localBF = getBfFilter();
		int nodeCategory = getCategory();
		if (nodeCategory == 0) {
			Mapping queryResult = parseNALocally(content_EID);
			if (queryResult == null) {
				dht.put(content_EID, new Mapping(register.getNA(), register.getSerial(), register.getMove()));
				if (!(parentNode == null)) {
					new MsgSender(this, parentNode, register).sendUDPMsg();
				}
			} else {
				if (Integer.parseInt(register.getSerial()) <= Integer.parseInt(queryResult.getSerial())) {
					return false;
				}
				dht.put(content_EID, new Mapping(register.getNA(), register.getSerial(), register.getMove()));
				if (!(parentNode == null)) {
					new MsgSender(this, parentNode, register).sendUDPMsg();
				}
			}
		} else if (nodeCategory == 1) {
			updateBFInfo(src_eid, content_EID);
			if (register.getMove() == 1) {
				getBfFilter().add(content_EID);
			} else if (register.getMove() == 2) {
				if (!localBF.contains(content_EID)) {
					getBfFilter().add(content_EID);
					if (!(parentNode == null)) {
						new MsgSender(this, parentNode, register).sendUDPMsg();
					}
				}
			}
		} else if (nodeCategory > 1) {
			updateBFInfo(src_eid, content_EID);
			if (!localBF.contains(content_EID)) {
				getBfFilter().add(content_EID);
				if (!(parentNode == null)) {
					new MsgSender(this, parentNode, register).sendUDPMsg();
				}
			}
		}
		return true;
	}

	public Mapping parseNA(Search search) {
		String content_EID = search.getEID();
		int category = getCategory();
		BloomFilter<String> localBF = getBfFilter();
		if (category == 0) {
			Mapping result = parseNALocally(content_EID);
			if (!(result == null)) {
				return result;
			} else {
				ArrayList<Node> nodes = new ArrayList<Node>();
				nodes.add(getParentNode());
				return parseByNodes(nodes, search);
			}
		}
		if (localBF.contains(content_EID)) {
			ArrayList<Node> nodes = new ArrayList<Node>();
			for (Node node : childNodes) {
				if (node.getBfFilter().contains(content_EID)) {
					nodes.add(node);
				}
			}
			return parseByNodes(nodes, search);
		} else {
			ArrayList<Node> nodes = new ArrayList<Node>();
			for (Node node : neighborNodes) {
				if (node.getBfFilter().contains(content_EID)) {
					nodes.add(node);
				}
			}
			if (search.getTrack() == 2 || category > 1) {
				nodes.add(getParentNode());
			}
			return parseByNodes(nodes, search);
		}
	}

	public Mapping parseByNodes(ArrayList<Node> nodes, Search search) {
		byte[] recvMsg = new byte[Config.UDP_PACKET_LENGTH];
		try {
			DatagramSocket sock = new DatagramSocket(0);
			sock.setSoTimeout(getTs());
			for (Node node : nodes) {
				ICN_head icn_head = new ICN_head();
				icn_head.setSRC_EID(getEID());
				icn_head.setDST_EID(node.getEID());
				byte[] headBytes = icn_head.ICN2bytes();
				byte[] msgBytes = search.genContentData();
				byte[] data = SocketUtil.addBytes(headBytes, msgBytes);
				DatagramPacket sendPacket = new DatagramPacket(data, data.length,
						InetAddress.getByName(node.getAddress()), node.getPort());
				sock.send(sendPacket);
			}
			DatagramPacket recvPacket = new DatagramPacket(recvMsg, recvMsg.length);
			sock.receive(recvPacket);
			sock.close();
		} catch (Exception e) {
			log.error(e.toString());
		}
		Search_Ack result = new Search_Ack();
		result.parseContentData(recvMsg);
		return new Mapping(result.getNA(), result.getSerial());
	}

	public Mapping parseNALocally(String content_EID) {
		Mapping result = dht.get(content_EID);
		return result;

	}

	public void updateBFInfo(String src_EID, String content_EID) {
		for (Node node : childNodes) {
			if (node.getEID().equals(src_EID)) {
				node.getBfFilter().add(content_EID);
				break;
			}
		}
	}

	public void showNodeInfo() {
		int parentNum = -1;
		if (parentNode != null) {
			parentNum = parentNode.getNum();
		}
		ArrayList<Integer> childNodesName = new ArrayList<Integer>();
		for (Node temp : childNodes) {
			childNodesName.add(temp.getNum());
		}
		ArrayList<Integer> neightborNodesName = new ArrayList<Integer>();
		for (Node temp : neighborNodes) {
			neightborNodesName.add(temp.getNum());
		}
		String info = "\n###Node Info### " + "\n# Node Num:" + getNum() + "\n# Node ID:" + getEID()
				+ "\n# Node Category:" + getCategory() + "\n# Node Address:" + getAddress() + "\n# Node Port:"
				+ getPort() + "\n# Parent Num:" + parentNum + "\n# Neightbor Nodes:" + neightborNodesName
				+ "\n# Child Nodes:" + childNodesName + "\n# TS:" + ts + "\n######";
		log.info(info);
	}

	public void addNeighbor(Node node) {
		neighborNodes.add(node);
	}

	public void addChild(Node node) {
		childNodes.add(node);
	}

}
