package dsp.icn.model;

import lombok.Data;

@Data
public class Mapping {
	private String NA;
	private String serial;
	private int move;

	public Mapping(String address, String serial) {
		NA = address;
		this.serial = serial;
	}

	public Mapping(String address, String serial, int move) {
		NA = address;
		this.serial = serial;
		this.move = move;
	}

}
