package dsp.icn.protocol;

import java.io.ByteArrayOutputStream;

import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Search_Ack implements ControlMsg {

	// 长度均以字节（byte）为单位
	public static final int GROUP_LEN = 1;
	public static final int ID_LEN = 16;
	public static final int NA_LEN = 4;
	public static final int SERIAL_LEN = 4;

	private byte group = 0;
	private String EID = null;
	private String NA = null;
	private String serial = null;

	/**
	 * 拼接发送数据，此处拼接了协议版本、协议类型和数据长度，具体内容子类中再拼接 按顺序拼接
	 *
	 * @return
	 */
	public byte[] genContentData() {
		byte[] ID = SocketUtil.hexStringToBytes(getEID());
		byte[] na = SocketUtil.hexStringToBytes(getNA());
		byte[] serial = SocketUtil.hexStringToBytes(getSerial());
		ByteArrayOutputStream baos = new ByteArrayOutputStream(GROUP_LEN + ID_LEN + NA_LEN + SERIAL_LEN);
		baos.write(group);
		baos.write(ID, 0, ID_LEN);
		baos.write(na, 0, NA_LEN);
		baos.write(serial, 0, SERIAL_LEN);
		return baos.toByteArray();
	}

	/**
	 * 解析接收数据，此处解析了协议版本、协议类型和数据长度，具体内容子类中再解析
	 *
	 * @param data
	 * @return
	 */
	public int parseContentData(byte[] data) {
		setGroup(data[0]);
		setEID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN, ID_LEN)));
		setNA(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN + ID_LEN, NA_LEN)));
		setSerial(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN + ID_LEN + NA_LEN, SERIAL_LEN)));
		return GROUP_LEN + ID_LEN + NA_LEN + SERIAL_LEN;
	}

}