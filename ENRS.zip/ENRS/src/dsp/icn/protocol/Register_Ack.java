package dsp.icn.protocol;

import java.io.ByteArrayOutputStream;

import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Register_Ack implements ControlMsg {

	// 长度均以字节（byte）为单位
	public static final int GROUP_LEN = 1;
	public static final int ID_LEN = 16;
	protected static final int ACK_LEN = 1;

	private byte group = 0;
	private String EID = null;
	private byte ack = 0;

	/**
	 * 拼接发送数据，此处拼接了协议版本、协议类型和数据长度，具体内容子类中再拼接 按顺序拼接
	 *
	 * @return
	 */
	public byte[] genContentData() {
		byte[] ID = SocketUtil.hexStringToBytes(getEID());
		ByteArrayOutputStream baos = new ByteArrayOutputStream(GROUP_LEN + ID_LEN + ACK_LEN);
		baos.write(group);
		baos.write(ID, 0, ID_LEN);
		baos.write(ack);
		return baos.toByteArray();
	}

	/**
	 * 解析接收数据，此处解析了协议版本、协议类型和数据长度，具体内容子类中再解析
	 *
	 * @param data
	 * @return
	 */
	public int parseContentData(byte[] data) {
		setGroup(data[0]);
		setEID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN, ID_LEN)));
		setAck(data[GROUP_LEN + ID_LEN]);
		return GROUP_LEN + ID_LEN + ACK_LEN;
	}

}