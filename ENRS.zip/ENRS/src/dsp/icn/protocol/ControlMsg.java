package dsp.icn.protocol;

public interface ControlMsg{
	public byte[] genContentData();

}
