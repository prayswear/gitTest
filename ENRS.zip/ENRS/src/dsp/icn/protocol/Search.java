package dsp.icn.protocol;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Search implements ControlMsg {

	// 长度均以字节（byte）为单位
	public static final int GROUP_LEN = 1;
	public static final int ID_LEN = 16;
	protected static final int TRACK_LEN = 1;

	private byte group = 0;
	private String EID = null;
	private byte track = 0;
	private String track_flag = "0";
	private String track_neighbor = "0";
	private String originCNode = "0";
	private String track_level = "00000";

	/**
	 * 拼接发送数据，此处拼接了协议版本、协议类型和数据长度，具体内容子类中再拼接 按顺序拼接
	 *
	 * @return
	 */
	public byte[] genContentData() {
		byte[] ID = SocketUtil.hexStringToBytes(getEID());
		String Track = getTrack_flag() + getTrack_neighbor() + getOriginCNode() + getTrack_level();
		setTrack(SocketUtil.BitToByte(Track));
		ByteArrayOutputStream baos = new ByteArrayOutputStream(GROUP_LEN + ID_LEN + TRACK_LEN);
		baos.write(group);
		baos.write(ID, 0, ID_LEN);
		baos.write(track);
		return baos.toByteArray();
	}

	protected String parseTrack_flag(byte[] data) {
		byte r = data[GROUP_LEN + ID_LEN];
		return String.valueOf((r >> 7) & 0x1);
	}

	protected String parseTrack_neighbor(byte[] data) {
		byte r = data[GROUP_LEN + ID_LEN];
		return String.valueOf((r >> 6) & 0x1);
	}

	protected String parseOrigin(byte[] data) {
		byte r = data[GROUP_LEN + ID_LEN];
		return String.valueOf((r >> 5) & 0x1);
	}

	protected String parseTrack_level(byte[] data) {
		byte r = data[GROUP_LEN + ID_LEN];
		return SocketUtil.byteToBit(r).substring(3, 8);
	}

	/**
	 * 解析接收数据，此处解析了协议版本、协议类型和数据长度，具体内容子类中再解析
	 *
	 * @param data
	 * @return
	 * @throws ProtocolException
	 *             协议版本不一致，抛出异常
	 */
	public int parseContentData(byte[] data) {
		setGroup(data[0]);
		setEID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN, ID_LEN)));
		setTrack_flag(parseTrack_flag(data));
		setTrack_neighbor(parseTrack_neighbor(data));
		setOriginCNode(parseOrigin(data));
		setTrack_level(parseTrack_level(data));
		return GROUP_LEN + ID_LEN + TRACK_LEN;
	}

}