package dsp.icn.protocol;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.java.Log;
import lombok.extern.log4j.Log4j2;

@Data
@NoArgsConstructor
@Log4j2
public class ICN_head {
	// 长度均以字节（byte）为单位
	// 源EID长度
	public static final int SRC_EID_LEN = 16;
	// 目的EID长度
	public static final int DST_EID_LEN = 16;
	// 服务类型长度
	public static final int TYPE_LEN = 1;
	// 首部长度占字节数
	public static final int HEAD_LENGTH_LEN = 1;
	// 校验和长度
	public static final int CHECKSUM_LEN = 2;
	// 固定首部长度
	public static final int FIXED_LEN = SRC_EID_LEN + DST_EID_LEN + TYPE_LEN + HEAD_LENGTH_LEN + CHECKSUM_LEN;
	// TLV长度
	protected int TLV_LEN = 0;
	// 发送者EID
	private String SRC_EID;
	// 接受者EID
	private String DST_EID;
	// 服务类型
	private byte type;
	// 首部长度
	private byte head_len;
	// 校验和
	private String checksum;
	// TLV字段
	private String tlv;

	public void setTlv(String tlv) {
		this.tlv = tlv;
		this.TLV_LEN = tlv.length();
	}

	/**
	 * 拼接发送数据，此处拼接了协议版本、协议类型和数据长度，具体内容子类中再拼接 按顺序拼接
	 *
	 * @return
	 */
	public byte[] ICN2bytes() {
		byte[] SRC_EID = SocketUtil.hexStringToBytes(getSRC_EID());
		byte[] DST_EID = SocketUtil.hexStringToBytes(getDST_EID());
		byte[] tlv = SocketUtil.hexStringToBytes(getTlv());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		baos.write(SRC_EID, 0, SRC_EID_LEN);
		baos.write(DST_EID, 0, DST_EID_LEN);
		baos.write(getType());
		baos.write(getHead_len());
		byte[] Checksum = SocketUtil.SumCheck(baos.toByteArray(), baos.size());
		baos = new ByteArrayOutputStream();
		baos.write(SRC_EID, 0, SRC_EID_LEN);
		baos.write(DST_EID, 0, DST_EID_LEN);
		baos.write(getType());
		baos.write(getHead_len());
		baos.write(Checksum, 0, CHECKSUM_LEN);
		if (TLV_LEN > 0) {
			baos.write(tlv, 0, TLV_LEN);
		}
		return baos.toByteArray();
	}

	/**
	 * 解析接收数据，此处解析了协议版本、协议类型、数据长度和校验和，具体内容子类中再解析
	 * 
	 * @param data
	 * @return
	 */
	public int bytes2ICN(byte[] data) {
		setSRC_EID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, 0, SRC_EID_LEN)));
		setDST_EID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, SRC_EID_LEN, DST_EID_LEN)));
		setType(data[SRC_EID_LEN + DST_EID_LEN]);
		setHead_len(data[SRC_EID_LEN + DST_EID_LEN + TYPE_LEN]);
		setChecksum(SocketUtil.bytesToHexString(
				SocketUtil.subBytes(data, SRC_EID_LEN + DST_EID_LEN + TYPE_LEN + HEAD_LENGTH_LEN, CHECKSUM_LEN)));
		setTLV_LEN(head_len - FIXED_LEN);
		if (TLV_LEN > 0) {
			setTlv(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, FIXED_LEN, TLV_LEN)));
		}
		return head_len;
	}

	public ICN_head(byte[] data) {
		bytes2ICN(data);
	}

}