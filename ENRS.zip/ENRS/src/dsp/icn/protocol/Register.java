package dsp.icn.protocol;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import dsp.icn.util.SocketUtil;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Register implements ControlMsg {

	// 长度均以字节（byte）为单位
	public static final int GROUP_LEN = 1;
	public static final int ID_LEN = 16;
	public static final int NA_LEN = 4;
	public static final int TIME_LEN = 4;
	public static final int MOVE_LEN = 1;

	private byte group;
	private String EID;
	private String NA;
	private String serial;
	private byte move;

	/**
	 * 拼接发送数据，此处拼接了协议版本、协议类型和数据长度，具体内容子类中再拼接 按顺序拼接
	 *
	 * @return
	 */
	public byte[] genContentData() {
		byte[] ID = SocketUtil.hexStringToBytes(getEID());
		byte[] na = SocketUtil.hexStringToBytes(getNA());
		byte[] time = SocketUtil.hexStringToBytes(getSerial());
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		baos.write(group);
		baos.write(ID, 0, ID_LEN);
		baos.write(na, 0, NA_LEN);
		baos.write(time, 0, TIME_LEN);
		baos.write(move);
		return baos.toByteArray();
	}

	/**
	 * 解析接收数据，此处解析了协议版本、协议类型和数据长度，具体内容子类中再解析
	 *
	 * @param data
	 * @return
	 * @throws ProtocolException
	 *             协议版本不一致，抛出异常
	 */
	public int parseContentData(byte[] data) {
		setGroup(data[0]);
		setEID(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN, ID_LEN)));
		setNA(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN + ID_LEN, NA_LEN)));
		setSerial(SocketUtil.bytesToHexString(SocketUtil.subBytes(data, GROUP_LEN + ID_LEN + NA_LEN, TIME_LEN)));
		setMove(data[GROUP_LEN + ID_LEN + NA_LEN + TIME_LEN]);
		return GROUP_LEN + ID_LEN + NA_LEN + TIME_LEN + MOVE_LEN;
	}

}