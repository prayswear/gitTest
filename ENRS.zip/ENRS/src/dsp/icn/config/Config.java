package dsp.icn.config;

public class Config {
	// UDP数据长度
	public static final int UDP_PACKET_LENGTH = 128;
	// BF预期元素100000个
	public static int BF_EXPECTED_NUM = 100000;
	// BF假阳性概率1e-5
	public static double BF_FALSE_PROPORTION = 1.E-005D;

}
