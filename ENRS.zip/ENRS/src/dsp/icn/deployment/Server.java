package dsp.icn.deployment;

import dsp.icn.model.CNode;
import lombok.Data;

@Data
public class Server extends Thread {
	private CNode node;

	public Server(CNode node) {
		this.node = node;
	}

	@Override
	public void run() {
//		node.showNodeInfo();
		node.startService();
		super.run();
	}

}
