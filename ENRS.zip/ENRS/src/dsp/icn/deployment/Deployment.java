package dsp.icn.deployment;

import java.util.ArrayList;
import java.util.Map;

import dsp.icn.model.CNode;
import dsp.icn.util.Excel;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class Deployment {
	public static ArrayList<Map<Integer, String>> distance_data = new ArrayList<Map<Integer, String>>();

	public static void main(String[] args) {
		String tsFilePath = "res/delay_table.xls";
		Deployment d1 = new Deployment();
		distance_data = Excel.readExcel(tsFilePath);
		
	}

}
