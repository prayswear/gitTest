package dsp.icn.deployment;

import java.util.ArrayList;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import dsp.icn.model.CNode;
import dsp.icn.model.ContainerNode;
import dsp.icn.model.Node;
import dsp.icn.util.Excel;

/**
 * 管理容器节点的拓扑关系
 * 
 * @author 47521
 *
 */
public class SimpleDeployment {
	private static Logger logger = LogManager.getLogger(SimpleDeployment.class.getName());
	// 容器节点数组
	public CNode[] nodes;

	public Server[] servers;
	// 容器节点数目
	public int nodeNum;
	// 容器树分叉数
	public int branchNum;
	// 设置起始端口号
	public int startPort;
	// 存储节点间传输时延信息
	public static ArrayList<Map<Integer, String>> distance_data = new ArrayList<Map<Integer, String>>();

	public SimpleDeployment(int nodeNum, int branchNum) {
		this.nodeNum = nodeNum;
		this.nodes = new CNode[nodeNum];
		this.branchNum = branchNum;
	}

	public static void main(String[] args) {
		// 时延表路径
		String tsFilePath = "res/delay_table.xls";
		int nodeNum = 7;
		int branchNum = 2;
		SimpleDeployment t1 = new SimpleDeployment(nodeNum, branchNum);
		t1.startPort = 9000;

		distance_data = Excel.readExcel(tsFilePath);
		logger.info("Node numb:" + distance_data.size());
		logger.info(distance_data.get(0));

		// 初始化各容器
		for (int i = 0; i < t1.nodeNum; i++) {
			t1.nodes[i] = new CNode("127.0.0.1", t1.startPort + i);
			t1.nodes[i].setEID("0000000000000000000000000000000" + i);
			t1.nodes[i].setNum(i);
			t1.nodes[i].setDistance(distance_data.get(i));
		}
		t1.setRelation();
		for (int i = 0; i < t1.nodeNum; i++) {
			t1.nodes[i].setTs(1000 * (3 - t1.nodes[i].getCategory()));
			if (t1.nodes[i].getCategory() == 0) {
				t1.nodes[i].setCategory(2);
			} else if (t1.nodes[i].getCategory() == 2) {
				t1.nodes[i].setCategory(0);
			}
		}
		for (int i = 0; i < t1.nodeNum; i++) {
			new Server(t1.nodes[i]).start();
		}
	}

	/**
	 * 设置服务器节点拓扑关系，结构为n叉树
	 */
	public void setRelation() {
		int category = 0;
		for (int i = 0; i < nodeNum; i++) {
			if ((this.branchNum - 1) * i + 1 == Math.pow(this.branchNum, category + 1)) {
				category++;
			}
			CNode currentServer = this.nodes[i];
			currentServer.setCategory(category);
			for (int j = 0; j < this.branchNum; j++) {
				int point = this.branchNum * i + j + 1;
				if (point < nodeNum) {
					CNode temp = this.nodes[point];
					currentServer.addChild(temp);
					temp.setParentNode(this.nodes[i]);
				}
			}
			for (Node temp1 : currentServer.getChildNodes()) {
				for (Node temp2 : currentServer.getChildNodes()) {
					if (temp1 != temp2) {
						((CNode) temp1).addNeighbor(temp2);
					}
				}
			}
		}
	}

}
